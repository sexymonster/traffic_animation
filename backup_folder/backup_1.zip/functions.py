from road_object import *
import xml.etree.ElementTree as ET

def set_link_data(Net, Links):
    L_data = Links.split('</link>')
    # L2_data = ET.fromstring(Links)
    # lst = L2_data.findall('/user')
    # for item in lst:

    for i in range(len(L_data) - 1):
        temp1 = L_data[i].split('"')
        A = Link()
        # A.id = temp1[1]
        A.id = i
        # if temp1[3] == 'straight':
        A.type = temp1[3]
        A.num_lane = int(temp1[5])
        A.num_sect = int(temp1[7])
        A.ffspeed = int(temp1[9])
        # A.max_spd = int(temp1[11])
        A.max_spd = temp1[11]
        # A.min_spd = int(temp1[13])
        A.min_spd = temp1[13]

        #adjusting scale for drawing
        A.length = int(temp1[15])/1.5
        A.width = int(temp1[17]) * 30

        A.qmax = int(temp1[19])
        A.waveSpd = int(temp1[21])
        A.maxVeh = int(temp1[23])
        Net.Links.append(A)


def set_node_data(Net, Nodes):
    N_data = Nodes.split('</node>')

    for i in range(len(N_data) - 1):
        # for i in range(2):
        temp = N_data[i].split('<node ')
        temp1 = temp[1].split('<port ')
        n_temp = temp1[0].split('"')

        A = Node()
        # node data

        if len(n_temp) == 7:
            A.id = n_temp[1]
            A.type = n_temp[3]
            A.num_port = n_temp[5]

        elif len(n_temp) == 9:
            A.id = n_temp[1]
            A.type = n_temp[3]
            A.num_port = n_temp[5]
            A.num_connection = n_temp[7]

        # port data
        for j in range(1, len(temp1)):
            p_temp = temp1[j].split('"')
            port = Port(Net.Links[int(p_temp[1])])
            port.direction = int(p_temp[3])
            port.type = p_temp[5]
            port.connected_node = int(p_temp[7])
            A.ports.append(port)

        # connection data
        if n_temp[3] == 'intersection':

            temp2 = temp1[-1].split('<!--Phase setting -->')
            c_temp = temp2[0].split('</port>')[1]
            temp3 = temp2[1].split('<!--Signal Plan -->')
            p_temp = temp3[0]
            s_temp = temp3[1]

            c_temp1 = c_temp.split('/>')
            for j in range(len(c_temp1) - 1):
                c_data = c_temp1[j].split('"')
                con = Connection()
                con.id = c_data[1]
                con.from_link = c_data[3]
                con.from_lane = c_data[5]
                con.to_link = c_data[7]
                con.to_lane = c_data[9]
                con.length = c_data[11]
                # con.priority = c_data[13]
                A.connections.append(con)

            # phase, signal?
        A.set_width_and_height()
        Net.Nodes.append(A)

    for i in range(len(Net.Nodes)):
        for j in range(len(Net.Nodes[i].ports)):
            idx = Net.Nodes[i].ports[j].connected_node
            Net.Nodes[i].ports[j].connected_node = Net.Nodes[idx]



def set_station_data(Net, Stations):
    pass