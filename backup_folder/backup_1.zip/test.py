import sys
from PyQt5.QtWidgets import *
from PyQt5.QtGui import *
from PyQt5.QtCore import *
from road_object import *
from functions import *


QApplication.setAttribute(Qt.AA_EnableHighDpiScaling, True)

class Map(QGraphicsView):

    def __init__(self, parent):
        super().__init__()
        self.scene = QGraphicsScene()
        self.setScene(self.scene)
        self.setRenderHint(QPainter.HighQualityAntialiasing)
        self.links_on_canvas = dict()
        self.nodes_on_canvas = []

        #draw tools
        self.dot_line = QPen(QColor(0, 0, 0), 4, Qt.DotLine)
        self.dot_line2 = QPen(Qt.black, 1, Qt.DotLine)
        self.dash_dot_line = QPen(Qt.black, 4, Qt.DashDotLine)
        self.n_line = QPen(Qt.black, 5)

        self.pen = QPen(Qt.lightGray, 0.1)
        self.brush = QBrush(Qt.lightGray)
        self.brush2 = QBrush(Qt.darkGray)
        self.brush3 = QBrush(Qt.black)

    def color_test(self):
        for rect in self.nodes_on_canvas:
            rect.setBrush(QColor(Qt.red))
            rect.setZValue(100)


    def draw_network(self, Network):
        coord = [0, 0, 0, 0]

        for i in range(len(Network.Nodes)):

            Node = Network.Nodes[i]
            if Node.type == 'terminal':
                continue
            else:
                break

        self.draw_node(Node,coord)

    def expanding(self,port,coord):

        if port.direction == 180:
            new_coord = [coord[0], coord[3] + port.link.length, coord[0], coord[3] + port.link.length]

            if port.connected_node.type == "terminal":
                new_coord[0] -= 10
                new_coord[2] += port.connected_node.width + 10
                new_coord[3] += 45

        elif port.direction == 90:
            new_coord = [coord[2] + port.link.length, coord[1], coord[2] + port.link.length, coord[1]]

            if port.connected_node.type == "terminal":
                new_coord[1] -= 10
                new_coord[2] += 45
                new_coord[3] += port.connected_node.height + 10

        elif port.direction == 0:
            new_coord = [coord[0], coord[1] - port.link.length, coord[0], coord[1] - port.link.length]

            if port.connected_node.type == "intersection":
                new_coord[1] -= port.connected_node.height
                new_coord[3] -= port.connected_node.height

            elif port.connected_node.type == "terminal":
                new_coord[0] -= 10
                new_coord[1] -= 45
                new_coord[2] +=  port.connected_node.width +10

        elif port.direction == 270:
            new_coord = [coord[0] - port.link.length, coord[1], coord[0] - port.link.length, coord[1]]

            if port.connected_node.type == "intersection":
                new_coord[0] -= port.connected_node.width
                new_coord[2] -= port.connected_node.width

            elif port.connected_node.type == "terminal":
                new_coord[0] -= 45
                new_coord[1] -= 10
                new_coord[3] += port.connected_node.height + 10

        port.link.on_canvas = True
        self.draw_node(port.connected_node, new_coord)

    def draw_link(self, port, A, B):

        x1 = A.x()
        y1 = A.y()

        x2 = B.x()
        y2 = B.y()

        if port.direction == 270 or port.direction == 90:
            interval = (y2 - y1) / 3
            for i in range(1,port.link.num_lane+1):
                print(port.link.id, x1, y1, x2, y2)
                lane = QRectF(QPointF(x1,y1 + interval* (i-1)), QPointF(x2,y1 + interval * i))
                lane_item = self.scene.addRect(lane, self.pen, self.brush)
                lane_item.setZValue(0)

                line = QLineF(QPointF(x1,y1+interval * i),QPointF(x2,  y1 + interval* i ))
                dot_line = self.scene.addLine(line, self.dot_line2)
                dot_line.setZValue(25)

                port.link.lanes[port.link.num_lane + 1 - i] = lane_item

        else:
            interval = (x2 - x1) / 3

            if port.direction == 180:
                print(port.link.id,x1,y1,x2,y2)
            for i in range(1,port.link.num_lane+1):

                lane = QRectF(QPointF(x1+ interval* (i-1),y1 ), QPointF(x1 + interval * i,y2 ))
                lane_item = self.scene.addRect(lane, self.pen, self.brush)
                lane_item.setZValue(0)

                line = QLineF(QPointF(x1 +interval * i,y1),QPointF(x1 +interval * i,  y2))
                dot_line = self.scene.addLine(line, self.dot_line2)
                dot_line.setZValue(25)

                port.link.lanes[port.link.num_lane + 1 - i] = lane_item

        port.link.on_canvas = True

    def draw_node(self, Node, coord):

        if Node.on_canvas == False:
            # print(Node.id, coord, "draw start")

            if Node.type == 'terminal':
                # print("its terminal",Node.id, coord)
                A = QPointF(coord[0], coord[1])
                B = QPointF(coord[2], coord[3])
                rect = QRectF(A, B)
                item = self.scene.addRect(rect, self.n_line, self.brush2)
                self.nodes_on_canvas.append(item)
                item.setZValue(50)
                Node.on_canvas == True
                return

            for j in range(len(Node.ports)):

                port = Node.ports[j]

                # print(Node.id, "draw", port.link.id)

                if port.type == "out":

                    if port.direction == 270:
                        coord[3] += port.link.width
                        if port.link.on_canvas == True:
                        #     print("i am", Node.id, "and link id", port.link.id, "is already on canvas")
                            continue

                        A = QPointF(coord[0], coord[1])
                        B = QPointF(coord[2] - port.link.length, coord[3])
                        C = QPointF(coord[0] - port.link.length, coord[1])

                        self.expanding(port, coord)


                    elif port.direction == 180:
                        coord[2] += port.link.width

                        if port.link.on_canvas == True:
                            # print("i am", Node.id, "and link id", port.link.id, "is already on canvas")
                            continue

                        A = QPointF(coord[0], coord[3])
                        B = QPointF(coord[2], coord[3] + port.link.length)
                        C = QPointF(coord[0], coord[3] + port.link.length)


                        self.expanding(port,coord)


                    elif port.direction == 0:

                        if port.link.on_canvas == True:
                            # print("i am", Node.id, "and link id", port.link.id, "is already on canvas")
                            continue

                        A = QPointF(coord[2], coord[1])
                        B = QPointF(coord[2] - port.link.width, coord[1] - port.link.length)
                        C = QPointF(coord[2], coord[1] - port.link.length)
                        D = QPointF(coord[2] - port.link.width, coord[1])

                        line = QLineF(D, B)
                        dash_line = self.scene.addLine(line, self.dash_dot_line)
                        dash_line.setZValue(25)

                    elif port.direction == 90:
                        if port.link.on_canvas == True:
                            # print("i am", Node.id, "and link id", port.link.id, "is already on canvas")
                            continue

                        A = QPointF(coord[2], coord[3])
                        B = QPointF(coord[2] + port.link.length, coord[3] - port.link.width)
                        C = QPointF(coord[2] + port.link.length, coord[3])
                        D = QPointF(coord[2], coord[3] - port.link.width)

                        line = QLineF(D, B)

                        dash_line = self.scene.addLine(line, self.dash_dot_line)
                        dash_line.setZValue(25)


                # in type
                else:
                    if port.direction == 270:

                        coord[3] += port.link.width

                        if port.link.on_canvas == True:
                            # print("i am", Node.id, "and link id", port.link.id, "is already on canvas")
                            continue

                        A = QPointF(coord[2], coord[3])
                        B = QPointF(coord[2] - port.link.length, coord[3] - port.link.width)
                        C = QPointF(coord[2] - port.link.length, coord[3])
                        D = QPointF(coord[2], coord[3] - port.link.width)

                        line = QLineF(B, D)
                        dash_line = self.scene.addLine(line, self.dash_dot_line)
                        dash_line.setZValue(25)

                    elif port.direction == 180:

                        coord[2] += port.link.width

                        if port.link.on_canvas == True:
                            # print("i am", Node.id, "and link id", port.link.id, "is already on canvas")
                            continue

                        A = QPointF(coord[2], coord[3])
                        B = QPointF(coord[2] - port.link.width, coord[3] + port.link.length)
                        C = QPointF(coord[2] - port.link.width, coord[3] + port.link.length)
                        D = QPointF(coord[2]- port.link.width, coord[3])

                        line = QLineF(D, C)
                        normal_line = self.scene.addLine(line, self.dash_dot_line)
                        normal_line.setZValue(25)


                    elif port.direction == 0:
                        if port.link.on_canvas == True:
                            # print("i am", Node.id, "and link id", port.link.id, "is already on canvas")
                            continue

                        A = QPointF(coord[0], coord[1])
                        B = QPointF(coord[0] + port.link.width, coord[1] - port.link.length)
                        C = QPointF(coord[0], coord[1] - port.link.length)

                        self.expanding(port, coord)

                    elif port.direction == 90:

                        if port.link.on_canvas == True:
                            # print("i am", Node.id, "and link id", port.link.id, "is already on canvas")
                            continue

                        A = QPointF(coord[2], coord[1])
                        B = QPointF(coord[2] + port.link.length, coord[1] + port.link.width)
                        C = QPointF(coord[2] + port.link.length, coord[1])
                        self.expanding(port,coord)

                self.draw_link(port, A, B)

            if Node.type == "intersection":
                A = QPointF(coord[0], coord[1])
                B = QPointF(coord[2], coord[3])
                rect = QRectF(A, B)
                item = self.scene.addRect(rect, self.dot_line, self.brush)
                item.setZValue(25)

            elif Node.type == "normal":
                A = QPointF(coord[0], coord[1])
                B = QPointF(coord[2], coord[3])

                line = QLineF(A, B)
                dot_line = self.scene.addLine(line, self.dot_line)
                dot_line.setZValue(25)

            Node.on_canvas = True
            # print(Node.id, coord, "end")

        else:
            print("Node", Node.id,"is already on canvas")


class MyWidget(QWidget):

    def __init__(self, parent):
        # super(FormWidget, self).__init__(parent)
        super().__init__(parent)
        self.layout = QVBoxLayout(self)
        self.view = Map(self)

        self.Net = Network()

        self.button1 = QPushButton("Button 1")
        self.button1.clicked.connect(self.file_open)

        self.button2 = QPushButton("Button 2")
        self.button2.clicked.connect(self.view.color_test)

        self.gb = QGroupBox('color test')
        self.grid = QGridLayout()
        self.gb.setLayout(self.grid)

        self.grid.addWidget(QLabel('Link'),0,0)
        self.combo = QComboBox()
        self.grid.addWidget(self.combo, 0, 1)
        for i in range(0, 27):
            self.combo.addItem(str(i))

        self.grid.addWidget(QLabel('Lane'),1,0)
        self.combo2 = QComboBox()
        self.grid.addWidget(self.combo2, 1, 1)
        for i in range(1,4):
            self.combo2.addItem(str(i))



        self.layout.addWidget(self.view)
        self.layout.addWidget(self.button1)
        self.layout.addWidget(self.button2)
        self.layout.addWidget(self.gb)
        self.setLayout(self.layout)

    def file_open(self):

        filename = QFileDialog.getOpenFileName()
        if filename[0] == "":
            return
        elif filename[0].split(".")[-1] != "xml":
            err = QMessageBox()
            err.about(self, "Load Error", "열 수 없는 파일 포맷입니다.(only .xmlR file)")
            return
        f = open(filename[0], 'r')

        data = f.read().split('<links>')

        temp= data[0].split('</nodes>')
        Links = data[1]
        Nodes = temp[0]
        Stations = temp[1]

        set_link_data(self.Net,Links)
        set_node_data(self.Net,Nodes)
        set_station_data(self.Net,Stations)

        self.view.draw_network(self.Net)



class Form(QMainWindow):

    def __init__(self):
        super().__init__()
        self.form_widget = MyWidget(self)
        self.setCentralWidget(self.form_widget)
        self.initUI()

    def initUI(self):

        # status bar
        self.statusBar().showMessage('Ready')

        #some funcs
        exitAction = QAction(QIcon('hmm.png'), 'Exit', self)
        exitAction.setStatusTip('Exit application')
        exitAction.setShortcut('Ctrl+Q')
        exitAction.triggered.connect(qApp.quit)

        # menubar
        menubar = self.menuBar()
        menubar.setNativeMenuBar(False)
        filemenu = menubar.addMenu('&File')
        filemenu.addAction(exitAction)

        # toolbar
        self.toolbar = self.addToolBar('Exit')
        self.toolbar.addAction(exitAction)
        self.resize(1000, 1000)
        self.setWindowTitle('Statusbar')
        # self.setGeometry(300, 300, 300, 200)
        self.center()

        self.show()

    def center(self):
        qr = self.frameGeometry()
        cp = QDesktopWidget().availableGeometry().center()
        qr.moveCenter(cp)
        self.move(qr.topLeft())

    def ct(self, state):
        self.setWindowTitle('fu')
        self.btn.setText('dsds')

    def onActivated(self, text):
        self.lbl.setText(text)
        self.lbl.adjustSize()
        self.lbl_red.setText(text)
        self.lbl_red.adjustSize()

    def onChanged(self, text):
        self.lblt.setText(text)
        self.lblt.adjustSize()


if __name__ == '__main__':
    app = QApplication(sys.argv)
    form = Form()
    form.show()
    exit(app.exec_())